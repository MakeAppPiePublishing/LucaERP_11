//
//  CRUDableReportApp.swift
//  CRUDableReport
//
//  Created by Steven Lipton on 6/24/25.
//

import SwiftUI

@main
struct CRUDableReportApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
