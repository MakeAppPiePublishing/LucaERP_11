import SwiftUI

protocol Activatable{
    var isActive:Bool{get set}
}
