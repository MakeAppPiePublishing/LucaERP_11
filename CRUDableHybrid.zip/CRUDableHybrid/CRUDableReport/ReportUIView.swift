//
//  ReportUIView.swift
//  CRUDableReport-Demo
//
//  Created by Steven Lipton on 7/20/25.
//

import SwiftUI

struct ReportUIView: View {
 
// Parameters for the view ------------------------------
    @Binding var parentID:Int
    @Binding var errorType:ErrorType
    @Binding var message:String
    
// The model ---------------------------------------------
    typealias Model = IngredientModel
    typealias Row = IngredientModelRow
    @State private var childModel:Model = Model()
    @State private var selectedChildRow:Row = Model().blank
    
    
// State variables for display ---------------------------
    @State private var ingredient:String = ""
    @State private var isActive:Bool = true

// Internal variables-----------------------------------------
    @State private var showInactive:Bool = false

    /// The count of active items in the model.
    /// - Use this for animation trigger for changin activity of models
    var countActive:Int{
        childModel.table.filter({$0.isActive}).count
    }
    
    
    var body: some View {
        LazyVStack(alignment:.leading){
// THe buttons for the table ----------------------------------
            HStack{
                // Add a Row ---------------------------------
                Button{
                    let newId = childModel.nextID
                    let newRow = Row(id: newId, parentID: parentID, isActive: true, name: "")
                    performAction(actionMode: .add, newRow: newRow)
                } label:{
                    Image(systemName: "plus")
                }
                .reportInlineButtonModifier()
                
                Spacer()
                // Toggle Inactive Row display -----------------------------------
                Button{
                    showInactive.toggle()
                } label:{
                    Image(systemName:"eye")
                        .symbolVariant(showInactive ? .none : .slash)
                }
                .reportInlineButtonModifier()
                
            }
            .padding(3)
            //horizontal scroll view for more coulmns than fit on screen.
            ScrollView(.horizontal){
                //Table heading - place labels here ------------------------------
                HStack{
                    Text("Parent").frame(width:50)
                        .columnLabelStyle
                    Text("ID").frame(width:50)
                        .columnLabelStyle
                    Text("Name").frame(width:200)
                        .columnLabelStyle
                    Spacer()
                }
                .background(.thinMaterial)
                Divider()
                // - scroll view might go here, but I'd suggest in TemplateUIView for better use in iPad
                
                //Loop for iterating over Rows-------------------------------------
                    ForEach($childModel.table.filter({$row in row.parentID == parentID && (row.isActive || showInactive) })){$row in
                        Button{
                            selectedChildRow = row
                        }
                        label:{
                //Display the row here ---------------------------------------------
                                HStack{
                            //Show independent of selection, usually read-only columns
                                    LPIntField(label: "", value: $row.parentID, isActive: false, labelWidth: 0, fieldWidth: 50)
                                    LPIntField(label: "", value: $row.id, isActive: false, labelWidth: 0, fieldWidth: 50)
                            // Show when row is selected ---------------------------
                                    if isSelectedRow(row){
                                        LPTextField(label: "", contents: $ingredient, isActive: row.isActive, labelWidth: 0, fieldWidth: 200)
                                        Spacer()
                //menu for row operations ------------------------------------------
                                        Menu {
                                            //Deletion -----------------------------
                                            Button{
                                                performAction(actionMode: .delete, newRow: selectedChildRow)
                                            } label:{
                                                Label("Delete", systemImage: "trash")
                                            }
                                            //Inactivation -------------------------
                                            Button{
                                                toggleActive()
                                            } label:{
                                                Label(isActive ? "Inactivate" : "Activate", systemImage:"sleep")
                                            }
                                        } label: {
                                            Image(systemName:"ellipsis.circle")
                                        }
                                    } else {
                // display when not selected
                                        Text(row.name).frame(width:200)
                                    }
                                    
                                    Spacer()
                                    
                                }
                                .foregroundStyle(.black.opacity(row.isActive ? 1.0 : 0.5))
                                .background(.yellow.opacity(selectedChildRow.id == row.id ? 1.0 : 0.01))
                        }
                    }
                
            }
        }
        .animation(.bouncy, value: countActive)
        .animation(.bouncy, value: showInactive)
//Update the row when the selection changes-----------------------------------------------
        .onChange(of: selectedChildRow.id) { oldValue, newValue in
            if  oldValue >= 0{
                let newRow = Row(id: oldValue, parentID: parentID, isActive: isActive, name: ingredient)
                performAction(actionMode: .update, newRow: newRow)
                ingredient = selectedChildRow.name
            }
            ingredient = selectedChildRow.name
            isActive = selectedChildRow.isActive
        }
    }
//------------------------------------------------------------------
//Methods ----------------------------------------------------------
//------------------------------------------------------------------
    
    ///Decide if row is a selected row.
    func isSelectedRow(_ row:Row)->Bool{
        return row.id == selectedChildRow.id
    }
    
    ///Toggle the row between active and inactive in the state variable
    func toggleActive(){
        isActive.toggle()
        message = "\(selectedChildRow.id) " + (isActive ? "Activated" : "Deactiviated")
        selectedChildRow = childModel.blank
    }
    
    ///Perform all CRUD actions based on `Crudable` and `CRUDAction`s
    func performAction(actionMode:CRUDAction,newRow:Row){
        //---------- Change the `newRow` to initialize to your Row's struct
        switch actionMode{
        case .add:
            errorType = childModel.add(row:newRow)
            if errorType == .noError{
                message = "\(newRow.id) added sucessfully"
            } else {
                message = "\(newRow.id) not added"
            }
            selectedChildRow = newRow
            
        case .update:
            errorType = childModel.update(id: newRow.id, newRow: newRow, isActive: true)
            if errorType == .noError{
                message = "\(newRow.id) updated sucessfully"
            } else {
                message = "\(newRow.id) not updated"
            }
        case .search:
            let result = childModel.find(id:newRow.id)
            errorType = result.errorType
            if errorType == .noError{
                selectedChildRow = result.row
                message = "\(newRow.id) found"
            } else {
                message = "\(newRow.id) not found"
            }
        case .delete:
            errorType = childModel.remove(id:newRow.id)
            if errorType == .noError{
                message = "Sucessfully deleted"
            } else {
                message = "No action taken"
            }
        default:
            // do nothing
            break
        }
    }
}

#Preview {
    @Previewable @State var parentID = 0
    @Previewable @State var errorType:ErrorType = .noError
    @Previewable @State var message:String = ""
    ReportUIView(parentID: $parentID,errorType:$errorType, message:$message).padding()
}
