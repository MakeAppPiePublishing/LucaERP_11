//
//  CRUDAction.swift
//  My App
//
//  Created by Steven Lipton on 6/3/25.
//

import SwiftUI

enum NavigationAction:String,CaseIterable{
    case first = "First"
    case previous = "Previous"
    case next = "Next"
    case last = "Last"
    case noAction = ""
    
    var icon:some View{
        switch self{
        case .first: return Image(systemName:"chevron.backward.2")
        case .last: return Image(systemName:"chevron.forward.2" )
        case .previous: return Image(systemName:"chevron.backward")
        case .next:return Image(systemName:"chevron.forward")
        default: return Image(systemName: "square")
        }
    }
}
