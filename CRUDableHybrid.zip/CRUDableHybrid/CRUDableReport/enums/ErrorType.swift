import SwiftUI

enum ErrorType:String{
    
    
    case noError = "No error Found"
    case recordNotFound = "Record not found"
    case recordExists = "Record already exists"
    case readOnly = "Cannot change row"
    case noDelete = "Cannot delete row" //added 5/2/25 
    
    var icon:some View{
        // Constants for images 
        let ok = Image(systemName: "checkmark.circle").foregroundStyle(.green)
        let warning = Image(systemName: "exclamationmark.circle.fill").foregroundStyle(.yellow)
        let fatal = Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.red)
        
        // determine the correct icon
        switch self{
        case .noDelete: return warning
        case .recordNotFound: return fatal
        case .recordExists: return fatal
        case .readOnly: return warning
        default: return ok
        }
    }
}


