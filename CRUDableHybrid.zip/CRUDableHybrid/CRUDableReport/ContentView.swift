//
//  ContentView.swift
//  CRUDableReport
//
//  Created by Steven Lipton on 6/24/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       TemplateUIView()
    }
}

#Preview {
    ContentView()
}
