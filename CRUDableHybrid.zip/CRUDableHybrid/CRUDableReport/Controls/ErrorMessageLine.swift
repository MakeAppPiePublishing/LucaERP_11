import SwiftUI

struct ErrorMessageLine:View{
    var errorType:ErrorType
    var message:String = ""
    
    var body: some View{
        HStack{
            if errorType != .noError {
                errorType.icon
                    .imageScale(.large)
                Text("Error:").bold()
                Text(errorType.rawValue)
                Image(systemName: "arrowshape.forward.fill")
            } 
            Text(message)
        }
        .padding()
    }
}

#Preview{
    ErrorMessageLine(errorType: .noError, message: "Hello Pizza")
}
