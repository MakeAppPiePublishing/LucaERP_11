import SwiftUI

struct LPTextField:View{
    var label:String
    @Binding var contents:String
    var isActive:Bool
    var labelWidth:Double
    var fieldWidth:Double
    
    init(label:String,contents:Binding<String>,isActive:Bool = true,fieldWidth:Double = 500){
        self.label = label
        self._contents = contents
        self.isActive = isActive
        self.labelWidth = fieldWidth * (label.isEmpty ? 0 : 0.25)
        self.fieldWidth = fieldWidth * (label.isEmpty ? 1 : 0.75)
    }
    
    init(label:String,contents:Binding<String>,isActive:Bool = true,labelWidth:Double,fieldWidth:Double){
        self.label = label
        self._contents = contents
        self.isActive = isActive
        self.labelWidth = labelWidth
        self.fieldWidth = fieldWidth
    }
    
    var body: some View{
        HStack{
            TextField(label, text: $contents)
                .lpFieldModifier(label: label, value: contents, isActive: isActive,labelWidth: labelWidth,fieldWidth: fieldWidth)
            }
        }
        
    }

#Preview{
    VStack(alignment:.leading){
        LPTextField(label:"Name",contents:.constant("Keiko Lopez"),isActive:false,labelWidth:100 ,fieldWidth: 300)
        LPTextField(label:"Department",contents:.constant("IT / Marketing"),isActive:false,labelWidth:100 ,fieldWidth: 300)
        
        Divider()
        HStack{
            Text("Name")
                .columnLabelStyle
                .frame(width:300)
            Text("Department")
                .columnLabelStyle
                .frame(width:300)
        }
        HStack{
            LPTextField(label:"",contents:.constant("Keiko Lopez"),isActive:false,labelWidth:0 ,fieldWidth: 300)
            LPTextField(label:"",contents:.constant("IT / Marketing"),isActive:false,labelWidth:0 ,fieldWidth: 300)
        }
    }
}
