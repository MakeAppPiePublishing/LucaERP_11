import SwiftUI

struct LPCheckBox:View{
    var label:String
    @Binding var value:Bool
    var isActive:Bool
    var fieldWidth:Double = 100.0
    
    var backgroundStyle:any ShapeStyle{
        isActive ? .white : .secondary
    }
    var body: some View{
        HStack{
            if !label.isEmpty{
                HStack{
                    Spacer()
                    Text(label).font(.caption).bold()
                        .padding(.trailing)
                }
                .frame(width:fieldWidth * 0.25)
            }
            Image(systemName: value ? "x.square.fill": "square")
                .imageScale(.large)
                //.padding(3)
                //.background(isActive ? .clear : .inactiveBackground)
                .foregroundStyle(isActive ? .primary : .tertiary)
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .onTapGesture{
                    if isActive{
                        value.toggle()
                    }
                }
            Spacer()
            
        }
        .frame(width:fieldWidth)
        
    }
}

#Preview{
    LPCheckBox(label: "Check On", value: .constant(false), isActive: true)
}
