import SwiftUI

struct LPIntField:View{
    var label:String
    @Binding var value:Int
    var isActive:Bool = true
    var labelWidth:Double
    var fieldWidth:Double
    
    init(label:String,value:Binding<Int>,isActive:Bool = true,fieldWidth:Double = 500){
        self.label = label
        self._value = value
        self.isActive = isActive
        self.labelWidth = fieldWidth * (label.isEmpty ? 0 : 0.25)
        self.fieldWidth = fieldWidth * (label.isEmpty ? 1 : 0.75)
    }
    
    init(label:String,value:Binding<Int>,isActive:Bool = true,labelWidth:Double,fieldWidth:Double){
        self.label = label
        self._value = value
        self.isActive = isActive
        self.labelWidth = labelWidth
        self.fieldWidth = fieldWidth
    }
    
    var formatter:Formatter{
        let formatter = NumberFormatter()
        formatter.numberStyle = .none
        return formatter
    }
    
    var body: some View{
        HStack{
            TextField(label,value:$value,formatter: formatter)
                .lpFieldModifier(label: label, value: formatter.string(for: value) ?? "", isActive: isActive,labelWidth: labelWidth,fieldWidth: fieldWidth)
                .keyboardType(.numberPad)
        }
    }
}
