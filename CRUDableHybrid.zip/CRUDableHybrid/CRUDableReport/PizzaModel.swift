import SwiftUI


//model based on https://makeapppie.com/huli-pizza-company/


struct TestModelRow:Identifiable,Activatable,Equatable{
    var id:Int
    var isActive: Bool = true
    var name:String
}


class PizzaModel:Crudable{
    typealias Row = TestModelRow
    var table:[Row] = [
        TestModelRow(id: 0,isActive:true, name: "Huli Pizza"),
        TestModelRow(id: 1,isActive:true, name: "Longboard"),
        TestModelRow(id: 2,isActive:true, name: "Pepperoni Pizza"),
        TestModelRow(id: 3,isActive:true, name: "Margherita")
    ]
    var blank:Row{
        TestModelRow(id: -1, isActive: false, name: "")
    }
    
    var nextID:Int{
        (table.map{$0.id}.max{$0<$1} ?? -1 ) + 1
    }
    
}

struct IngredientModelRow:Identifiable,Activatable,Equatable{
    var id:Int
    var parentID:Int
    var isActive: Bool = true
    var name:String
}

class IngredientModel:Crudable{
    typealias Row = IngredientModelRow
    var table:[Row] = [
        // with huli huli chicken, onions, ginger, crushed macadamia nuts, tomato sauce and cheese on a classic crust.
        IngredientModelRow(id: 0, parentID: 0, name: "Hawaiian crust"),
        IngredientModelRow(id: 1, parentID: 0, name: "huli huli Chicken"),
        IngredientModelRow(id: 2, parentID: 0, name: "onions"),
        IngredientModelRow(id: 3, parentID: 0, name: "fresh ginger"),
        IngredientModelRow(id: 4, parentID: 0, name: "mac nuts"),
        IngredientModelRow(id: 5, parentID: 0, name: "tomato sauce"),
        IngredientModelRow(id: 6, parentID: 0, name: "firm mozzarella"),
        IngredientModelRow(id: 7, parentID: 0, name: "Huli Sauce"),
        //A very long flatbread for vegetarians and vegans, made with olive oil, mushrooms, garlic, fresh ginger, and macadamias, sweetened with lilikoi.
        IngredientModelRow(id: 8, parentID: 1, name: "classic rust"),
        IngredientModelRow(id: 9, parentID: 1, name: "olive oil"),
        IngredientModelRow(id: 10, parentID: 1, name: "mushrooms"),
        IngredientModelRow(id: 11, parentID: 1, name: "Garlic"),
        IngredientModelRow(id: 12, parentID: 1, name: "fresh ginger"),
        IngredientModelRow(id: 13, parentID: 1, name: "mac nuts"),
        IngredientModelRow(id: 14, parentID: 1, name: "lilikoi sauce"),
        //The New York Classic version. A thin crust with pizza sauce, cheese, and pepperoni
        IngredientModelRow(id: 15, parentID: 2, name: "New York crust"),
        IngredientModelRow(id: 16, parentID: 2, name: "firm mozzarella"),
        IngredientModelRow(id: 17, parentID: 2, name: "pepperoni"),
        IngredientModelRow(id: 18, parentID: 2, name: "pizza sauce"),
        //The classic pizza of Buffalo Mozzarella, tomatoes, and basil on a classic crust.
        IngredientModelRow(id: 19, parentID: 3, name: "classic crust"),
        IngredientModelRow(id: 20, parentID: 3, name: "tomatoes"),
        IngredientModelRow(id: 21, parentID: 3, name: "fresh basil leaves"),
        IngredientModelRow(id: 22, parentID: 3, name: "Buffalo mozzarella"),
    ]
    
    var blank:Row{
        Row(id: -1,parentID: -1, isActive: false, name: "")
    }
    
    var nextID:Int{
        (table.map{$0.id}.max{$0<$1} ?? -1 ) + 1
    }
}


