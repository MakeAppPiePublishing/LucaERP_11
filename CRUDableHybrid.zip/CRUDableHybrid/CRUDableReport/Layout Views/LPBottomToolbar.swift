import SwiftUI



struct LPBottomToolbar:View{
    @Binding var error:ErrorType
    @Binding var message:String
    @Binding var action:CRUDAction
    @Binding var isPresented:Bool 
    @Binding var doAction:Bool 
    
    var body:some View{
        HStack{
            ErrorMessageLine(errorType: error, message: message)
            Spacer()
            Button{
                doAction = true
            } label:{
                Text(action.rawValue)
            }
            .buttonModifier
            
            Button("Cancel"){
                action = .search
                isPresented = false
            }
            .buttonModifier
        }
        .padding()
        .background(.regularMaterial)
    }
        
}

#Preview{
    @Previewable @State var message = "10111 is read-only"
    @Previewable @State var action:CRUDAction = .update
    @Previewable @State var errorType:ErrorType = .noDelete
    @Previewable @State var isPresented:Bool = true
    @Previewable @State var doAction:Bool = false
    LPBottomToolbar(error: $errorType, message: $message, action: $action,isPresented: $isPresented,doAction: $doAction)
}
