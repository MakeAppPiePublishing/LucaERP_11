import SwiftUI

struct LPNavigationBar:View{
    @Binding var navAction:NavigationAction
    @Binding var displayMode: CRUDAction
    var message1:String = ""
    var message2:String = ""
    var body: some View{
        VStack{
//            HStack{
//                Text(message1).font(.caption2)
//                Spacer()
//                Text(message2).font(.caption2)
//            }
        HStack{
            // display mode buttons
            ForEach (CRUDAction.allCases,id:\.self){ item in
                Button{
                    displayMode = item
                } label: {
                    item.icon
                }
                .fileNavButtonModifier(label:item.rawValue,disabled:displayMode == item)
            }
            
            Spacer()
            
            // Navigation in Table, skipping `.noAction`
            ForEach (NavigationAction.allCases,id:\.self){ item in
                if item != .noAction{
                    Button{
                        navAction = item
                    } label: {
                        item.icon
                    }
                    .fileNavButtonModifier(label:item.rawValue)
                }
            }
        }
    }
        .padding(5)
        .background(.regularMaterial)
    }
    
}

#Preview{
    @Previewable @State var navAction:NavigationAction = .noAction
    @Previewable @State var displayMode:CRUDAction = .update
    LPNavigationBar(navAction:$navAction, displayMode:$displayMode,message1:"Add",message2:"G/L")
}
