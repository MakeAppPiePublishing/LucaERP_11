import SwiftUI
// LPFieldModifier
// Steven Lipton 2/22/25
//
//

/// The formatting modifer to add a leading label to any view
///
struct LPFieldModifier:ViewModifier{
    var label:String
    var value:String
    var isActive:Bool = true
    //var totalFieldWidth:Double
    var labelWidth:Double
    var fieldWidth:Double
    
    //original with a twist. used to be default, but made for adding the modification below.
    init(label:String,value:String,isActive:Bool = true, totalFieldWidth:Double){
        self.label = label
        self.value = value
        self.isActive = isActive
        self.labelWidth = totalFieldWidth * (label.isEmpty ? 0 : 0.25)
        self.fieldWidth = totalFieldWidth * (label.isEmpty ? 1 : 0.75)
    }
    
    
    // modfication from original. this keeps columsn for both labels and fields to be specified.
    init(label:String,value:String,isActive:Bool = true,labelWidth:Double,fieldWidth:Double){
        self.label = label
        self.value = value
        self.isActive = isActive
        self.labelWidth = labelWidth
        self.fieldWidth = fieldWidth
    }

    
    func body(content:Content)-> some View{
        HStack{
            if !label.isEmpty{
                HStack{
                    Spacer()
                    Text(label)
                        .columnLabelStyle
                }
                .frame(width:labelWidth,height:40)
            }
            if isActive{
                content
                    .textFieldStyle(.roundedBorder)
                    .frame(width:fieldWidth,height:40)
                    .multilineTextAlignment(.leading)
            } else {
                    RoundedRectangle(cornerRadius:8)
                        .foregroundStyle(.regularMaterial)
                        .frame(width:fieldWidth,height:40)
                        .overlay{
                    HStack{
                        Text(value)
                            .padding(5)
                        Spacer()
                    }
                    
                }
            }
            
            Spacer()
        }
        .frame(width:(labelWidth+fieldWidth))
        .padding(.trailing,5)
        
    }
}

extension View{
    func lpFieldModifier(label:String,value:String,isActive:Bool = true,totalFieldWidth:Double = 500) -> some View{
        self.modifier(LPFieldModifier(label: label, value: value, isActive: isActive,totalFieldWidth:totalFieldWidth))
    }
    func lpFieldModifier(label:String,value:String,isActive:Bool = true,labelWidth:Double,fieldWidth:Double) -> some View{
        self.modifier(LPFieldModifier(label: label, value: value, isActive: isActive,labelWidth:labelWidth, fieldWidth:fieldWidth))
    }
    
    static  var inactiveBackground:Color{Color(white: 0, opacity: 0.10)}
    
}
