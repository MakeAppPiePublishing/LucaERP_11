import SwiftUI

struct ButtonModifier:ViewModifier{
    var scale:Image.Scale = .medium
    func body(content:Content) -> some View{
        content
            .font(.body).bold()
            .imageScale(scale)
            .padding()
            .frame(minWidth:125)
            .background(.blue)
            .foregroundStyle(.white)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .padding(.trailing,5)
        
    }
}

struct FileNavButtonModifier:ViewModifier{
    var label:String = ""
    var disabled:Bool = false
    var scale:Image.Scale = .large
    var frameSize:CGFloat{
        switch scale{
        case .small: return 15
        case .medium: return 30
        case .large:return 50
        default: return 50
        }
    }
    func body(content: Content) -> some View {
        VStack{
            content
                .imageScale(scale)
                .padding(5)
                .frame(width: frameSize,height:frameSize)
                .background(.blue, in: RoundedRectangle(cornerRadius: 8))
                .foregroundStyle(.white)
                .disabled(disabled)
                .opacity(disabled ? 0.5: 1)
            Text(label)
                .font(.caption2)
        }
    }
}

struct ReportInlineButtonModifier:ViewModifier{
    var disabled:Bool = false
    func body(content: Content) -> some View {
        VStack{
            content
                .imageScale(.small)
                .padding(5)
                .frame(width: 30,height:30)
                .background(.blue, in: RoundedRectangle(cornerRadius: 8))
                .foregroundStyle(.white)
                .disabled(disabled)
                .opacity(disabled ? 0.5: 1)
        }
    }
}

extension View{
    
    var buttonModifier:some View{
        self.modifier(ButtonModifier())
    }
    
    func fileNavButtonModifier(label:String = "", disabled:Bool = false)-> some View{
        return self.modifier(FileNavButtonModifier(label:label,disabled:disabled))
    }
    func reportInlineButtonModifier(disabled:Bool = false)-> some View{
        return self.modifier(ReportInlineButtonModifier(disabled:disabled))
    }
}
