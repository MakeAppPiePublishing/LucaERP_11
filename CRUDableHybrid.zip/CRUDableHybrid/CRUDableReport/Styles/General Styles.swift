import SwiftUI



struct ColumnLabelStyle:ViewModifier{
    func body(content:Content) -> some View{
        content
            .font(.caption).bold()
    }
}

extension View{
     var columnLabelStyle: some View{
        self.modifier(ColumnLabelStyle())
    }
}

